public void export(String destination, String data) {

    String encoded = Base64.getEncoder().encodeToString(data.getBytes());

    String payload = "[BASE64_CIPHERTEXT:" + encoded + "]";

    super.export(destination, payload);
}