package task1;

public abstract class ExporterDecorator implements Exporter {
    protected Exporter exporter;

    public ExporterDecorator(Exporter exporter) {
        this.exporter = exporter;
    }

    public void export(String destination, String data) {
        exporter.export(destination,data);

    }
}
