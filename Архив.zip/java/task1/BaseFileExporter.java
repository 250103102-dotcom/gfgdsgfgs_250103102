package task1;

public class BaseFileExporter implements Exporter {
    public void export(String destination, String data) {

        System.out.println("[DISK WRITE] Writing " + data.length() + " bytes to file://" + destination);

        System.out.println("- FILE PAYLOAD BEGIN -");
        System.out.println(data);
        System.out.println("- FILE PAYLOAD END -");
    }
}
