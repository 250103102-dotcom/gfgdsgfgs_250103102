package task1;
public class CsvFormatter implements ReportFormatter {
    public String format(String title, String[] headers, String[][] rows) {
        String result = "# TITLE: " + title + "\n";
        for (int i = 0; i < headers.length; i++) {
            result += headers[i];

            if (i < headers.length - 1) {
                result += ",";
            }
        }
        result += "\n";
        for (int i = 0; i < rows.length; i++) {
            for (int j = 0; j < rows[i].length; j++) {
                result += rows[i][j];
                if (j < rows[i].length - 1) {
                    result += ",";
                }
            }
            result += "\n";
        }
        return result;
    }
}
