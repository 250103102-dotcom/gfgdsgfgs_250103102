package task1;
public class JsonFormatter implements ReportFormatter {
    public String format(String title, String[] headers, String[][] rows) {
        String result = "{\n";
        result += "\"report\": \"" + title + "\",\n";
        result += "\"records\": [\n";
        for (int i = 0; i < rows.length; i++) {
            result += "{";
            for (int j = 0; j < headers.length; j++) {
                result += "\"" + headers[j] + "\": \"" + rows[i][j] + "\"";

                if (j < headers.length - 1) {
                    result += ", ";
                }
            }
            result += "}";
            if (i < rows.length - 1) {
                result += ",";
            }
            result += "\n";
        }
        result += "]\n}";
        return result;
    }
}