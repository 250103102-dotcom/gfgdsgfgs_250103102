package task1;
public class Task1Runner {
    public static void main(String[] args) {
        String[] headers = {"ID", "User", "Role"};
        String[][] rows = {
                {"101", "sufyan", "Admin"},
                {"102", "alex", "Dev"}
        };

        ReportFormatter formatter = new JsonFormatter();

        String data = formatter.format("UserAuditReport", headers, rows);
        Exporter exporter = new BaseFileExporter();

        exporter = new Base64EncryptDecorator(exporter);

        exporter = new HeaderFooterDecorator(
                exporter, "2026-11-02 10:00:00 UTC");

        exporter.export("/var/logs/audit.sec", data);
    }
}
