package task1;

public class HeaderFooterDecorator extends ExporterDecorator {

    private String timestamp;

    public HeaderFooterDecorator(Exporter exporter, String timestamp) {
        super(exporter);
        this.timestamp = timestamp;
    }
    public void export(String destination,String data) {

        String newData = "- EXPORT TIMESTAMP: " + timestamp + " -\n";
        newData += data;
        newData += "\n- RECORD COUNT: 2 | SECURE HASH: [OK] -";
        super.export(destination,newData);
    }
}
