package task3;

public class ImmediateStrategy implements DispatchStrategy {

    public boolean shouldDispatch(int severityLevel, int currentHour) {
        return true;
    }

    public String getStrategyName() {
        return "IMMEDIATE_DISPATCH";
    }
}
