package task2;

import java.util.HashMap;
import java.util.Map;

public class CachedStockProxy implements StockProvider {
    private StockProvider realProvider;
    private long ttlMillis;
    private Map<String, Double> cache = new HashMap<>();

    private Map<String, Long> timeCache = new HashMap<>();

    public CachedStockProxy(StockProvider realProvider, long ttlMillis) {
        this.realProvider = realProvider;
        this.ttlMillis = ttlMillis;
    }

    public double getMarketPrice(String ticker) {

        long now = System.currentTimeMillis();

        if (cache.containsKey(ticker)) {

            long oldTime = timeCache.get(ticker);

            if (now - oldTime < ttlMillis) {

                System.out.println("[CACHE HIT] Returning cached price for " + ticker);

                return cache.get(ticker);
            }
        }

        System.out.println("[NETWORK FETCH] Cache miss or expired for " + ticker + ". Calling upstream adapter...");

        double price = realProvider.getMarketPrice(ticker);

        cache.put(ticker, price);
        timeCache.put(ticker, now);

        return price;
    }

    public String getStatus(String ticker) {
        return realProvider.getStatus(ticker);
    }
}
