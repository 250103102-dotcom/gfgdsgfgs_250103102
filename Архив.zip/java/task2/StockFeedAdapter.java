package task2;

import java.util.HashMap;
import java.util.Map;

public class StockFeedAdapter implements StockProvider {

    private LegacyStockFeed legacyFeed;

    public StockFeedAdapter(LegacyStockFeed legacyFeed) {
        this.legacyFeed = legacyFeed;
    }

    private Map<String, String> parsePacket(String raw) {

        Map<String, String> map = new HashMap<>();

        String[] parts = raw.split(";");

        for (String part : parts) {
            String[] values = part.split("=");

            if (values.length == 2) {
                map.put(values[0], values[1]);
            }
        }

        return map;
    }

    public double getMarketPrice(String ticker) {

        String raw = legacyFeed.fetchRawTickerPacket(ticker);

        Map<String, String> data = parsePacket(raw);

        double bid = Double.parseDouble(data.get("BID"));
        double ask = Double.parseDouble(data.get("ASK"));

        return (bid + ask) / 2;
    }

    public String getStatus(String ticker) {

        String raw = legacyFeed.fetchRawTickerPacket(ticker);

        Map<String, String> data = parsePacket(raw);

        return data.get("STATUS");
    }
}
